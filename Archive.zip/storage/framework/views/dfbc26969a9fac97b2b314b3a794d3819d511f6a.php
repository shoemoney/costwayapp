<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Document</title>

    <?php $__env->startSection('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <?php echo $__env->yieldSection(); ?>
</head>
<body class="bg-gray-100">
    <?php echo $__env->make('layouts.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    <?php echo $__env->yieldSection(); ?>
</body>
</html>
<?php /**PATH /Users/joshuacallis/web/project/resources/views/layouts/app.blade.php ENDPATH**/ ?>