<?php $__env->startSection('title', $store->name); ?>

<?php $__env->startSection('scripts'); ?>
  ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
  <script src="<?php echo e(mix('js/stores/show.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="flex flex-col w-0 flex-1 overflow-hidden" id="stores-show">
    <?php echo $__env->make('components.sidebar-toggle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="flex-1 relative z-0 overflow-y-auto pt-2 pb-6 focus:outline-none md:py-6" tabindex="0" x-data x-init="$el.focus()">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <h1 class="text-2xl font-semibold text-gray-900"><?php echo e($store->name); ?></h1>
      </div>

      <div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <ul>
          <li v-for="product in products">
            <a :href="'/product/' + product.id" class="block hover:bg-gray-50 focus:outline-none focus:bg-gray-50 transition duration-150 ease-in-out">
              <div class="flex items-center px-4 py-4 sm:px-6">
                <div class="min-w-0 flex-1 flex items-center">
                  <div class="flex-shrink-0">
                    <img class="h-12 w-12" :src="imageUrl(product)" />
                  </div>
                  <div class="min-w-0 flex-1 px-4">
                    <div>
                      <div class="text-sm leading-5 font-medium text-indigo-600 truncate" v-text="product.name"></div>
                      <div class="mt-2 flex items-center text-sm leading-5 text-gray-500">
                        <div class="flex">
                          <span>
                            <span v-text="product.price / 100"></span> <span v-text="product.currency"></span>
                          </span>
                          <span class="mx-2">|</span>
                          <span>
                            <span v-text="product.sales_count"></span> <span>sales tracked</span>
                          </span>
                        </div>
                      </div>
                    </div>
                    <!-- <div class="hidden md:block">
                      <div>
                        <div class="text-sm leading-5 text-gray-900">
                          Watched since
                          <span v-text="formattedDate(product.created_at)"></span>
                        </div>
                        <div class="mt-2 flex items-center text-sm leading-5 text-gray-500">
                          <svg class="flex-shrink-0 mr-1.5 h-5 w-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                          </svg>
                          Completed phone screening
                        </div>
                      </div>
                    </div> -->
                  </div>
                </div>
                <div>
                  <svg class="h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/>
                  </svg>
                </div>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </main>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/joshuacallis/web/project/resources/views/stores/show.blade.php ENDPATH**/ ?>