
The stock level for <?php echo e($product->name); ?> is low.
<br>
Current stock level is: <?php echo e($stock); ?>

<br>
Url: <a href="https://www.aliexpress.com/item/<?php echo e($product->identifier); ?>.html" target="_blank">Product URL</a>
<?php /**PATH /Users/joshuacallis/web/project/resources/views/emails/stocklow.blade.php ENDPATH**/ ?>