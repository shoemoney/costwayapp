
Product has been removed <?php echo e($product->name); ?>.

Url: <a href="<?php echo e($url); ?>/<?php echo e($product->identifier); ?>.html" target="_blank">Product URL</a>
<?php /**PATH /Users/joshuacallis/web/project/resources/views/emails/productremoved.blade.php ENDPATH**/ ?>