<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | DropShop</title>

    <?php $__env->startSection('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <?php echo $__env->yieldSection(); ?>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH /Users/joshuacallis/web/project/resources/views/layouts/auth.blade.php ENDPATH**/ ?>