<div id="app">
 <main class="flex">
    <aside
        class="flex flex-col justify-between shadow w-1/8 min-h-full bg-purple-600 text-sm text-gray-800"
      >
        <div class="flex flex-col mx-4 mb-12">
          <button class="text-white my-3 py-2 inline-flex items-start justify-start font-bold">
            <i class="text-blue fi fi-pie-chart-1"></i>
            <span>Dashboard</span>
          </button>
          <button class="text-white my-1 py-2 inline-flex items-center">
            <span>Account</span>
            <hr class />
          </button>
          <button class="text-white my-1 py-2 inline-flex items-center">
            <span>Products</span>
          </button>
          <button class="text-white my-1 py-2 inline-flex items-center">
            <span>Orders</span>
          </button>
        </div>
        <div class="flex flex-row mx-4 mb-12 text-teal">
          <a href="/" class="text-white">Support</a>
        </div>
    </aside>
    <section class="w-full text-sm">
        <div class="flex justify-between h-screen">
            <div class="w-1/4 bg-white shadow py-4 px-6 bg-gray-200 text-gray-800">
              <search></search>
            </div>
            <div class="w-2/6 bg-white shadow py-4 px-6">
              <div class="flex flex-wrap mx-2 my-4">
                <div class="flex flex-grow justify-start">
                  <h4>Products</h4>
                </div>
                <div class="flex flex-grow justify-end">
                  <button class="bg-purple-400 px-4 mr-1"><i class="fas fa-redo-alt" style="color: #805ad5;"></i></button>
                  <button class="bg-purple-400 px-4"><i class="fas fa-align-justify" style="color: #805ad5;"></i></button>
                </div>
              </div>
              <products :get-products="products"></products>
            </div>
            <div class="w-3/5 flex flex-col content-between bg-white shadow py-4 px-6 h-auto bg-gray-200">
            <div class="flex mb-4">
              <div class="w-full bg-white h-auto">
                <product-details :product-details="product"></product-details>
                <sales :product-identifier="product.identifier"></sales>
              </div>
            </div>
          </div>
        </div>
    </section>
  </main>
</div>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css" rel="stylesheet">
<style>
  .active {
    border-bottom-color: #6335c7;
  }
</style>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/web/project/resources/views/layouts/products.blade.php ENDPATH**/ ?>