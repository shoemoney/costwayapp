
Price changed on <?php echo e($product->name); ?>.
<br>
New price is <?php echo e($price); ?>

<br>
Old was was: <?php echo e($product->price); ?>

<br>
Url: <a href="<?php echo e($url); ?>/<?php echo e($product->identifier); ?>.html" target="_blank">Product URL</a>
<?php /**PATH /Users/joshuacallis/web/project/resources/views/emails/pricechanged.blade.php ENDPATH**/ ?>