<?php $__env->startSection('title', 'Imported Products'); ?>

<?php $__env->startSection('scripts'); ?>
  ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
  <script src="<?php echo e(mix('js/products/imported_products.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-col w-0 flex-1 overflow-hidden" id="imported_products">
    <?php echo $__env->make('components.sidebar-toggle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="flex-1 relative z-0 overflow-y-auto pt-2 pb-6 focus:outline-none md:py-6" tabindex="0" x-data x-init="$el.focus()">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <section id="header" class="mb-8">
            <h1 class="text-2xl font-semibold text-gray-900">Imported Products</h1>
              <div class="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  <imported-products :get-products="<?php echo e($products); ?>"></imported-products>
              </div>
        </section>
      </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/joshuacallis/web/project/resources/views/importedproducts/index.blade.php ENDPATH**/ ?>