<div class="container mx-auto px-4">
    <div class="flex items-center justify-between py-4">
    <div>
        <?php echo e(config('app.name')); ?>

    </div>

    <div class="hidden sm:flex sm:items-center">
        <a href="/products" class="text-gray-800 text-sm font-semibold hover:text-blue-600 mr-4">Products</a>
    </div>


</div>

    <div class="block sm:hidden bg-white border-t-2 py-2">
    <div class="flex flex-col">
        <a href="/products" class="text-gray-800 text-sm font-semibold hover:text-blue-600 mb-1">Products</a>
        <div class="flex justify-between items-center border-t-2 pt-2">
        <!-- <a href="#" class="text-gray-800 text-sm font-semibold hover:text-blue-600 mr-4">Sign in</a>
        <a href="#" class="text-gray-800 text-sm font-semibold border px-4 py-1 rounded-lg hover:text-blue-600 hover:border-blue-600">Sign up</a> -->
        </div>
    </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/web/project/resources/views/layouts/app/nav.blade.php ENDPATH**/ ?>