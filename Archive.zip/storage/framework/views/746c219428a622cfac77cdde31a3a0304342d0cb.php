<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'New Page'); ?> | DropShop</title>

    <?php $__env->startSection('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <?php echo $__env->yieldSection(); ?>
</head>
<body>

    <div class="h-screen flex overflow-hidden bg-gray-100" x-data="{ sidebarOpen: false }" @keydown.window.escape="sidebarOpen = false">
        <?php echo $__env->make('layouts.app.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php $__env->startSection('scripts'); ?>
        <script>
            window.data = <?php echo json_encode(get_defined_vars()['__data'], 15, 512) ?>;
        </script>
        <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.0.1/dist/alpine.js" defer></script>
        <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    <?php echo $__env->yieldSection(); ?>
</body>
</html>
<?php /**PATH /Users/joshuacallis/web/project/resources/views/layouts/master.blade.php ENDPATH**/ ?>