@extends('layouts.master')

@section('title', 'Tracked Products')

@section('scripts')
  @parent
  <script src="{{ mix('js/products/track_products.js') }}"></script>
@endsection

@section('content')
<div class="flex flex-col w-0 flex-1 overflow-hidden" id="track_products">
    @include('components.sidebar-toggle')

    <main class="flex-1 relative z-0 overflow-y-auto pt-2 pb-6 focus:outline-none md:py-6" tabindex="0" x-data x-init="$el.focus()">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <section id="header" class="mb-8">
            <h1 class="text-2xl font-semibold text-gray-900 px-4">Tracked Products</h1>
              <div class="mt-2">
                  <tracked-products :get-products="{{ $products }}"></tracked-products>
              </div>
        </section>
      </div>
    </main>
</div>
@endsection
