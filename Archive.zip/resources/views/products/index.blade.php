@extends('layouts.app')

@section('upper-content')
    <div class="bg-white rounded p-4">
    </div>
@endsection

@section('content')
    <div class="bg-white shadow-lg rounded">
        <div class="p-4">
            <!-- <products></products> -->
        </div>
    </div>
@endsection
