
Price changed on {{ $product->name}}.
<br>
New price is {{ $price }}
<br>
Old was was: {{ $product->price }}
<br>
Url: <a href="{{$url}}/{{ $product->identifier }}.html" target="_blank">Product URL</a>
