
Product has been removed {{ $product->name}}.

Url: <a href="{{$url}}/{{ $product->identifier }}.html" target="_blank">Product URL</a>
