
The stock level for {{ $product->name}} is low.
<br>
Current stock level is: {{ $stock }}
<br>
Url: <a href="https://www.aliexpress.com/item/{{ $product->identifier }}.html" target="_blank">Product URL</a>
