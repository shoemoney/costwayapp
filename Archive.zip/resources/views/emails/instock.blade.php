The product {{$product->name}} is {{ $stock }}
<br>
Url: <a href="https://costway.co.uk/{{ $product->identifier }}.html" target="_blank">Product URL</a>
