window.bus = new Vue({});

import Products from '../views/Products.vue'
import SearchProduct from '../views/product/SearchProduct.vue'
import SearchStore from '../views/product/SearchStore.vue'
import SearchCategory from '../views/product/SearchCategory.vue'
import Sales from '../views/metrics/Sales.vue'
import ProductDetails from '../views/ProductDetails.vue'

const products = new Vue({
    components: {
        Products,
        Sales,
        ProductDetails,
        SearchStore,
        SearchProduct,
        SearchCategory,
    },
    el: '#products',
    data: {
        products: [],
        product: {},
        salesEachMonth: [],
        salesEachDay: [],
        searchingProducts: false,
        searchingProductMetrics: false,
        currentSearch: '',
    },
    mounted() {
        this.getProducts;
        this.getProductDetails;
        this.productSearchFlag;
        this.productMetricSearhFlag;
        this.getSalesEachMonth;
        this.getSalesEachDay;
        this.getCurrentSearch;
    },
    computed: {
        getProductDetails() {
            bus.$on('product', (product) => {
                this.product = product;
            });
        },

        getProducts() {
            bus.$on('products', (products) => {
                this.products = products;
            });
        },

        productSearchFlag() {
            bus.$on('productSearchFlag', (flag) => {
                this.searchingProducts = flag;
            });
        },

        productMetricSearhFlag() {
            bus.$on('productMetricSearhFlag', (flag) => {
                this.searchingProductMetrics = flag;
            });
        },
        getSalesEachMonth() {
            bus.$on('salesEachMonth', (sales) => {
                this.salesEachMonth = sales;
            });
        },
        getSalesEachDay() {
            bus.$on('salesEachDay', (sales) => {
                this.salesEachDay = sales;
            });
        },
        getCurrentSearch() {
            bus.$on('currentSearch', (search) => {
                this.currentSearch = search;
            });
        }
    },
});