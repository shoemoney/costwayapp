let dayjs = require('dayjs');
let Chart = require('chart.js');

Chart.defaults.global.tooltips.intersect = false;
Chart.defaults.global.tooltips.mode = 'index';

const productsShow = new Vue({
    el: "#products-show",
    data() {
        return {
            product: window.data.product,
            grouped_sales: [],
            settings: {
                days: 30
            }
        }
    },
    methods: {
        latestSales(provider, identifier) {
            axios.get(`/products/${provider}/sales?identifier=${identifier}`)
                .then(() => {
                    this.refresh();
                });
        },
        groupedSales(provider, identifier) {
            axios.get(`/api/products/${identifier}/total-sales`)
                .then(({ data }) => {
                    this.grouped_sales = _.takeRight(data.data.reverse(), this.settings.days);
                    this.drawSalesChart(this.grouped_sales);
                });
        },
        drawSalesChart(sales) {
            drawSalesChart(sales);
        },
        refresh() {
            axios.get(window.location.href)
                .then(({ data }) => {
                    this.product = data.product;
                    this.groupedSales(this.product.provider, this.product.identifier);
                })
        },
        formatSaleDate(date) {
            return dayjs(date).format('DD MMMM YYYY')
        }
    },
    computed: {
        avgSalesPerDay() {
            const totalDaysWithSales = _.uniq(
                this.product.sales.map(sale => sale.sold_at)
            ).length;

            return Math.round(this.product.sales.length / totalDaysWithSales);
        },
        productImages() {
            const meta = _.find(this.product.metadata, meta => meta.key === 'images');

            return meta.value;
        }
    },
    mounted() {
        this.groupedSales(this.product.provider, this.product.identifier);
    },
});

function drawSalesChart(sales) {
    var ctx = document.getElementById('sales-chart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: sales.map((day) => {
                return day.date;
            }),
            datasets: [{
                label: '# of sales',
                data: sales.map((day) => {
                    return day.total_sold;
                }),
                backgroundColor: 'rgba(183, 148, 244, 0.4)',
                borderColor: '#6B46C1',
                borderWidth: 2,
                pointRadius: 0,
                lineTension: 0.25
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }],
                xAxes: [
                    {
                        ticks: {
                            margin: 0,
                            maxTicksLimit: Math.ceil(sales.length / 2),
                            fontColor: '#6e7a8a',
                        },
                        gridLines: {
                            display: false,
                            color: 'transparent',
                            drawBorder: false,
                        },
                    },
                ],
            }
        }
    });
}
