<template>
  <div>
    <div class="mt-4 bg-white p-1">
      <div class="flex-grow"></div>
      <input
        class="mt-1 p-2 block w-full appearance-none leading-normal focus:outline-none border-b-2 border-indigo-800"
        type="search"
        v-model="search"
        v-on:keyup="onSubmitProductByKeyWord"
        placeholder="Search products by a keyword"
      />
    </div>
    <div
      class="inline-flex mt-2 justify-center w-full"
      v-if="!_.isEmpty(getProducts) && onProductSearch"
    >
      <button
        class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 border-r-2 border-gray-400"
        @click="prev()"
      >Prev</button>
      <button
        class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4"
        @click="next()"
      >Next</button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    getProducts: Array,
    currentSearch: String
  },
  data() {
    return {
      search: "",
      page: 1
    };
  },
  methods: {
    onSubmitProductByKeyWord(e) {
      if (e.keyCode === 13) {
        this.searchProductByKeyword("ebay", this.search);
      }
    },
    searchProductByKeyword(vendor, keyword, page = 1) {
      this.searching();
      axios
        .get(`/products/${vendor}?keyword=${keyword}&page=${page}`)
        .then(({ data }) => {
          bus.$emit("products", data);
          bus.$emit("currentSearch", "product_keyword_search");
          this.searchComplete();
        });
    },
    prev() {
      if (this.page > 1) {
        this.page--;
        this.searchProductByKeyword("ebay", this.store, this.page);
      }
    },
    next() {
      this.page++;
      this.searchProductByKeyword("ebay", this.store, this.page);
    },
    searching() {
      bus.$emit("productSearchFlag", true);
    },
    searchComplete() {
      bus.$emit("productSearchFlag", false);
    }
  },
  computed: {
    onProductSearch() {
      return this.currentSearch === "product_keyword_search";
    }
  }
};
</script>
