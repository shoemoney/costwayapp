<template>
  <div>
    <store></store>
    <div class="mt-4 bg-white p-1 rounded">
      <div class="flex-grow"></div>
      <input
        class="mt-1 py-2 px-4 block w-full appearance-none leading-normal focus:outline-none border-b-2 border-indigo-800"
        type="search"
        v-model="store"
        v-on:keyup="onSubmitSearchStore"
        placeholder="Search store / fetch products"
      />
    </div>
    <div>
      <ul class="bg-gray-300 p-4 shadow" v-if="!_.isEmpty(stores)">
        <li
          v-for="(store, index) in stores"
          v-text="store"
          @click="searchStore('ebay', store)"
          class="cursor-pointer bg-indigo-500 w-full p-1 mt-2 text-white text-center border-b-4 border-indigo-700 active:border-indigo-700 hover:bg-indigo-600 focus:outline-none focus:bg-indigo-600"
        ></li>
      </ul>
    </div>
    <div
      v-if="!_.isEmpty(selectedStore) && _.isEmpty(stores) && onStoreSearch"
      class="inline-flex text-center text-white bg-gray-300 p-4 shadow w-full"
    >
      <span
        v-text="selectedStore"
        class="border-b-4 border-indigo-700 w-full bg-indigo-500 p-1 mt-2"
      ></span>
    </div>
    <div
      class="inline-flex mt-2 justify-center w-full"
      v-if="!_.isEmpty(getProducts) && onStoreSearch"
    >
      <button
        class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 border-r-2 border-gray-400"
        @click="prev()"
      >Prev</button>
      <button
        class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4"
        @click="next()"
      >Next</button>
    </div>
  </div>
</template>

<script>
import Store from "../../views/Store.vue";

export default {
  components: {
    Store
  },
  props: {
    getProducts: Array,
    currentSearch: String
  },
  data() {
    return {
      search: "",
      store: "",
      stores: [],
      page: 1,
      selectedStore: ""
    };
  },
  methods: {
    onSubmitSearchStore(e) {
      this.searchSavedStores(this.store, e);
      if (e.keyCode === 13) {
        this.searchStore("ebay", this.store);
      }
    },
    searchStore(vendor, store, page = 1) {
      this.searching();
      axios
        .get(`/products/${vendor}/stores?identifier=${store}&page=${page}`)
        .then(
          ({ data }) => {
            this.selectedStore = store;
            this.store = store;
            bus.$emit("products", data);
            bus.$emit("currentSearch", "product_store_search");
            this.emptyStoresList();
            this.searchComplete();
          },
          error => {
            // If search fails keep trying until it succeeds
            this.searchStore(this.store);
          }
        );
    },
    prev() {
      if (this.page > 1) {
        this.page--;
        this.searchStore("ebay", this.store, this.page);
      }
    },
    next() {
      this.page++;
      this.searchStore("ebay", this.store, this.page);
    },
    searchSavedStores(store, e) {
      // If the search contains numbers or letters then search.
      if (!store.match(/^[0-9a-zA-Z]+$/) && e.keyCode !== 13) {
        return;
      }
      axios.get(`search/store/${store}`).then(({ data }) => {
        this.emptyStoresList();
        this.stores = data;
      });
    },
    emptyStoresList() {
      this.stores = [];
    },
    searching() {
      bus.$emit("productSearchFlag", true);
    },
    searchComplete() {
      bus.$emit("productSearchFlag", false);
    }
  },
  computed: {
    onStoreSearch() {
      return this.currentSearch === "product_store_search";
    }
  }
};
</script>
