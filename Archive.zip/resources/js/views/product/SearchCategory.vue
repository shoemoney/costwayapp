<template>
  <div>
    <div class="mt-4 p-1">
      <input
        class="mt-1 py-2 px-4 block w-full appearance-none leading-normal focus:outline-none border-b-2 border-indigo-800"
        type="search"
        v-model="category"
        v-on:keyup="searcheBayCategories"
        placeholder="Search eBay Categories"
      />
      <div class="flex-grow py-1">
        <div>
          <ul class="bg-gray-300 p-4 shadow" v-if="!_.isEmpty(categories)">
            <li
              v-for="(category, index) in categories"
              v-text="category.name"
              @click="searchProductByCategory('ebay', category)"
              class="cursor-pointer bg-indigo-500 w-full p-1 mt-2 text-white text-center border-b-4 border-indigo-700 active:border-indigo-700 hover:bg-indigo-600 focus:outline-none focus:bg-indigo-600"
            ></li>
          </ul>
        </div>
      </div>
      <div v-if="!_.isEmpty(categories)" class="flex justify-center mt-1">
        <button
          v-if="categoryPage !== 1"
          class="text-xs bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 border-b-2 border-gray-400 h-14"
          @click="previousCategories()"
        >
          <i class="fas fa-chevron-left"></i>
        </button>
        <button
          class="text-xs bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 border-b-2 border-gray-400 px-6 h-14"
          @click="moreCategories()"
        >
          <i class="fas fa-chevron-right"></i>
        </button>
      </div>
      <div
        v-if="!_.isEmpty(selectedCategory) && _.isEmpty(categories) && onCategorySearch"
        class="inline-flex text-center text-white bg-gray-300 p-4 shadow w-full"
      >
        <span
          v-text="selectedCategory"
          class="border-b-4 border-indigo-700 w-full bg-indigo-500 p-1 mt-2"
        ></span>
      </div>
    </div>
    <div
      class="inline-flex mt-2 justify-center w-full"
      v-if="!_.isEmpty(getProducts) && onCategorySearch"
    >
      <button
        class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 border-r-2 border-gray-400"
        @click="prev()"
      >Prev</button>
      <button
        class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4"
        @click="next()"
      >Next</button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    getProducts: Array,
    currentSearch: String
  },
  data() {
    return {
      category: "",
      categoryObject: {},
      identifier: 0,
      categories: [],
      selectedCategory: "",
      page: 1,
      categoryPage: 1
    };
  },
  methods: {
    searcheBayCategories(e) {
      this.searchCategories(this.category, e);
    },
    searchProductByCategory(vendor, category, page = 1) {
      this.category = category.name;
      this.identifier = category.identifier;
      this.selectedCategory = category.name;
      this.categoryObject = category;
      this.searching();
      axios
        .get(
          `/products/${vendor}/categories?identifier=${this.identifier}&page=${page}`
        )
        .then(({ data }) => {
          bus.$emit("products", data);
          bus.$emit("currentSearch", "product_category_search");
          this.searchComplete();
          this.emptyCategoriesList();
        });
    },
    prev() {
      if (this.page > 1) {
        this.page--;
        this.searchProductByCategory("ebay", this.categoryObject, this.page);
      }
    },
    next() {
      this.page++;
      this.searchProductByCategory("ebay", this.categoryObject, this.page);
    },
    searchCategories(category, page = 1) {
      axios
        .get(`search/categories/${category}?page=${page}`)
        .then(({ data }) => {
          this.emptyCategoriesList();
          this.categories = data.data;
          this.resetCategoriesPage();
        });
    },
    moreCategories() {
      this.categoryPage++;
      this.searchCategories(this.categoryPage, this.categoryPage);
    },
    previousCategories() {
      if (this.categoryPage > 1) {
        this.categoryPage--;
      }
      this.searchCategories(this.categoryPage, this.categoryPage);
    },
    emptyCategoriesList() {
      this.categories = [];
    },
    searching() {
      bus.$emit("productSearchFlag", true);
    },
    searchComplete() {
      bus.$emit("productSearchFlag", false);
    }
  },
  computed: {
    onCategorySearch() {
      return this.currentSearch === "product_category_search";
    },
    resetCategoriesPage() {
      if (_.isEmpty(this.categories)) {
        this.categoryPage = 1;
      }
    }
  }
};
</script>
