<template>
  <div class="mt-4">
    Brands
    <div class="md:flex md:items-center mb-6">
      <label class="block">
        <input class="mr-2" type="checkbox" />
        <span class="text-sm">Brand (4)</span>
      </label>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {}
};
</script>
