<template>
  <ul class="block my-4 mx-auto" x-data="{selected:null}">
    <li class="flex align-center flex-col mb-4">
      <div
        @click="selected !== 0 ? selected = 0 : selected = null"
        class="active:bg-white flex cursor-pointer px-5 py-3 bg-gray text-center inline-block shadow hover:-mb-3 rounded-t"
      >
        <div class="flex flex-grow justify-start">
          <h4>
            <i class="far fa-money-bill-alt mr-2"></i>Filter something
          </h4>
        </div>
        <div class="flex flex-grow justify-end">
          <button class="px-2 focus:outline-none">
            <i class="fas fa-chevron-down"></i>
          </button>
        </div>
      </div>
      <div v-if="selected == 0" class="border py-4 px-2 opacity-75 shadow">
        <div class="md:flex md:items-center">
          <label class="block font-bold">
            <input class="mr-2" type="checkbox" />
            <span class="text-sm">4</span>
          </label>
        </div>
        <div class="md:flex md:items-center">
          <label class="block font-bold">
            <input class="mr-2" type="checkbox" />
            <span class="text-sm">6</span>
          </label>
        </div>
      </div>
    </li>
  </ul>
</template>

<script>
export default {
  data() {
    return {
      selected: null
    };
  },
  methods: {}
};
</script>
