<template>
  <div class="bg-gray-200 p-4 w-1/2 mt-1 text-gray-700">
    <p>Change price:</p>
    <div>
      <input
        type="text"
        placeholder="Change price"
        v-model="currentPrice"
        class="w-full text-black p-2 appearance-none leading-normal focus:outline-none border-b-2 border-indigo-800"
      />
    </div>
    <div>
      <div class="flex justify-start">
        <div>
          <p>Price after fees:</p>
          <div
            v-if="priceWithFees"
            class="text-white bg-indigo-800 py-1 px-2 text-center px-8"
          >£{{ priceWithFees.toFixed(2) }}</div>
        </div>
        <div class="ml-4">
          <p>Your profit:</p>
          <div
            v-if="profit"
            class="text-white bg-indigo-800 py-1 px-2 text-cente px-8"
          >£{{ profit }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    price: Number
  },
  data() {
    return {
      profit: 0,
      priceWithFees: 0,
      currentPrice: (parseInt(this.price) * 0.01).toFixed(2)
    };
  },
  computed: {
    originalPrice() {
      return (parseInt(this.price) * 0.01).toFixed(2);
    },
    productPrice() {
      return (parseInt(this.price) * 0.01).toFixed(2);
    }
  },
  methods: {
    setPriceWithFeesAndProfit(pr) {
      this.priceWithFees = pr - (pr * 0.129 + 0.03).toFixed(2);
      this.profit = (this.priceWithFees - this.originalPrice).toFixed(2);
    }
  },
  watch: {
    currentPrice: function(val) {
      this.setPriceWithFeesAndProfit(val);
    }
  },
  mounted() {
    this.setPriceWithFeesAndProfit(this.productPrice);
  }
};
</script>
