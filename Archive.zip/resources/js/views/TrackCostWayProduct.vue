<template>
  <div class="w-full p-2 flex justify-between text-gray-800">
    <div class="w-full p-2 mx-2 shadow px-6">
      <label class="font-bold my-2">Product Slug</label>
      <p v-if="_.isEmpty(product)">
        Example:
        <span class>adjustable-kid-basketball-stand-basketball-hoop-w-handle</span>
      </p>
      <input
        class="mt-1 py-1 px-2 block w-full leading-normal focus:outline-none"
        type="text"
        v-model="productSlug"
        v-on:keyup="productDetails"
      />
      <div v-if="!_.isEmpty(product)">
        <div class="my-2">
          <span
            v-text="product.stock"
            class="text-white bg-indigo-800 py-1 px-2 text-center px-4 py-1"
          ></span>
        </div>
        <label class="font-bold my-2">Title</label>
        <input
          class="mt-1 py-1 px-2 block w-full leading-normal focus:outline-none"
          type="text"
          v-model="product.title"
        />

        <img :src="product.mainImage" class="my-2 h-64" />
        <label class="font-bold my-2">Price</label>
        <input
          class="mt-1 py-1 px-2 block w-full leading-normal focus:outline-none"
          type="text"
          v-model="product.price"
        />
        <label class="font-bold my-2">Description</label>
        <textarea
          class="mt-1 py-1 px-2 block w-full leading-normal focus:outline-none"
          type="text"
          v-model="product.description"
          row="4"
          cols="30"
        />
      </div>
    </div>
    <div class="w-1/2" v-if="!_.isEmpty(product)">
      <div class="shadow px-6 bg-white p-2">
        <ul>
          <li>
            <span class="font-bold">Rating</span>
            <span v-text="product.rating"></span>
          </li>
          <li>
            <span class="font-bold">Review</span>
            <span v-text="product.reviews"></span>
          </li>
        </ul>
        <div class="p-2 mt-2 shadow px-6 bg-gray-200">
          <button
            @click="downloadImages(product.images)"
            class="border-b-4 text-white border-indigo-600 bg-indigo-800 p-1 mt-2 active:border-indigo-700 hover:border-indigo-700 hover:bg-indigo-600 focus:outline-none focus:bg-indigo-600 px-4"
          >Download all images</button>
        </div>
        <button
          @click="trackProduct"
          class="border-b-4 text-white border-indigo-600 bg-indigo-700 p-1 mt-2 active:border-indigo-800 hover:border-indigo-800 hover:bg-indigo-600 focus:outline-none focus:bg-indigo-600 px-4 w-full"
        >Track Product</button>
      </div>
    </div>
  </div>
</template>

<script>
import { saveAs } from "file-saver";

export default {
  data() {
    return {
      product: {},
      productSlug: ""
    };
  },
  methods: {
    productDetails() {
      axios.get(`/costway/product/${this.productSlug}`).then(({ data }) => {
        this.product = data;
      });
    },
    downloadImages(images) {
      images.forEach(image => {
        saveAs(
          image,
          image.replace(
            "https://www.costway.co.uk/media/catalog/product/cache/1/",
            ""
          )
        );
      });
    },
    trackProduct() {
      axios
        .post("/costway/product", {
          identifier: this.productSlug,
          name: this.product.title,
          description: this.product.description,
          price: this.product.price,
          currency: this.product.currency,
          images: this.product.images,
          stock: this.product.stock,
          rating: this.product.rating,
          reviews: this.product.reviews
        })
        .then(response => {
          this.$toasted.show("Product tracked.", {
            theme: "bubble",
            position: "bottom-center",
            duration: 1500
          });
        });
    }
  }
};
</script>
