<template>
  <div class="w-50 p-4 bg-white leading-loose px-4 text-gray-700" v-if="!_.isEmpty(productDetails)">
    <div class="text-xm text-gray-700">
      <span>eBay ProductID:</span>
      <span v-text="productDetails.identifier"></span>
      <div>
        <p>
          Watch count:
          <span v-text="productDetails.metrics.watch_count"></span>
        </p>
      </div>
    </div>
    <div v-for="image in productDetails.meta.images">
      <img :src="image.url" class="w-40" alt />
    </div>
    <a :href="productDetails.meta.url" target="_blank">
      <p v-text="productDetails.name" class="text-lg text-gray-900 hover:underline pr-4"></p>
    </a>
    <p v-text="productDetails.meta.categories.name"></p>
    <p v-text="sellerInfo"></p>
    <p>£{{ originalPrice }}</p>

    <profit-checker :price="productDetails.price"></profit-checker>
    <track-product :product-details="productDetails"></track-product>
  </div>
</template>

<script>
import ProfitChecker from "./ProfitChecker.vue";
import TrackProduct from "../components/TrackProduct.vue";

export default {
  components: {
    ProfitChecker,
    TrackProduct
  },
  props: {
    productDetails: {}
  },
  data() {
    return {
      toggleProfitChecker: false
    };
  },
  computed: {
    originalPrice() {
      return (parseInt(this.productDetails.price) * 0.01).toFixed(2);
    },
    sellerInfo() {
      return (
        this.productDetails.meta.sellerInfo.store +
        " | " +
        this.productDetails.meta.sellerInfo.feedbackScore +
        " | " +
        this.productDetails.meta.sellerInfo.feedbackPercent
      );
    }
  }
};
</script>
