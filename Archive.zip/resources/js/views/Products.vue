<template>
  <div class="scrolling-auto overflow-auto h-screen text-gray-700">
    <div v-if="productSearchFlag" class="flex justify-center items-center text-center flex-col">
      <img src="https://productimporterstore.thedevgroup.co.uk/img/progress.svg" alt />
      <p>
        Loading products
        <span v-if="lastSearchedSeller">
          from
          <span v-text="lastSearchedSeller" class="font-bold"></span>
        </span>
      </p>
    </div>
    <div v-if="products">
      <div class="sm:flex flex-wrap mb-1 flex justify-center" v-for="(product, index) in products">
        <div class="sm:flex-shrink-0">
          <img class="sm:w-40" :src="product.meta.images[0].url" />
        </div>
        <div class="mt-4 w-full">
          <a
            :href="product.meta.url"
            target="_blank"
            class="block mt-1 text-gray-900 hover:underline"
            v-text="product.name.substring(0, 40) + '...'"
          ></a>
          <div class="flex w-full mt-2">
            <p v-text="product.meta.categories.name"></p>
          </div>
          <div class="flex w-full mt-2">
            <span v-text="product.meta.sellerInfo.store"></span> |
            <span v-text="product.meta.sellerInfo.feedbackScore"></span> |
            <span v-text="product.meta.sellerInfo.feedbackPercent"></span>
          </div>
          <div class="flex w-full mt-2">
            <p v-text="product.currency + ' ' + product.price"></p>
          </div>
          <div
            @click="productDetails(product)"
            class="flex w-full mt-2 border-b-4 text-white border-indigo-600 bg-indigo-800 p-2 active:border-indigo-700 hover:border-indigo-700 hover:bg-indigo-600 focus:outline-none focus:bg-indigo-600 flex justify-center"
          >Details</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    getProducts: Array,
    productSearchFlag: Boolean,
    lastSearchedSeller: String
  },
  methods: {
    productDetails(product) {
      this.emptyProductMetrics();
      bus.$emit("product", product);
    },
    emptyProductMetrics() {
      bus.$emit("salesEachMonth", []);
      bus.$emit("salesEachDay", []);
    }
  },
  computed: {
    products() {
      return this.getProducts;
    }
  }
};
</script>
