<template>
  <div>
    <div class="mt-4 bg-white p-1 rounded">
      <div class="flex-grow"></div>
      <input
        class="mt-1 rounded-lg py-2 px-4 block w-full appearance-none leading-normal focus:outline-none"
        type="seller"
        v-model="store"
        v-on:keyup="addStore"
        placeholder="Watch a store"
      />
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      store: ""
    };
  },
  methods: {
    addStore(e) {
      if (e.keyCode === 13) {
        axios
          .post("/store", {
            identifier: this.store,
            provider: "ebay"
          })
          .then(response => {
            this.$toasted.show("Store successfully added!", {
              theme: "bubble",
              position: "bottom-center",
              duration: 1500
            });
            this.store = "";
          });
      }
    }
  }
};
</script>
