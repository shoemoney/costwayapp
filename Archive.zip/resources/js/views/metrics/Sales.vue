<template>
  <div class="w-50 m-2 p-4 bg-white" v-if="!_.isEmpty(productIdentifier)">
    <button
      @click="getProductSalesEachDay"
      v-if="!_.isEmpty(productIdentifier)"
      class="border-b-4 text-white border-indigo-600 bg-indigo-800 p-2 mt-2 active:border-indigo-700 hover:border-indigo-700 hover:bg-indigo-600 focus:outline-none focus:bg-indigo-600"
    >Sales each day and time</button>
    <button
      @click="getProductSalesTotalEachMonth"
      v-if="!_.isEmpty(productIdentifier)"
      class="border-b-4 text-white border-indigo-600 bg-indigo-800 p-2 mt-2 active:border-indigo-700 hover:border-indigo-700 hover:bg-indigo-600 focus:outline-none focus:bg-indigo-600"
    >Total sales and gross each day</button>
    <div class="abs-center" v-if="metricSearchFlag">
      <img src="https://productimporterstore.thedevgroup.co.uk/img/progress.svg" width="150px" />
    </div>
    <modal
      name="sales-each-day"
      height="auto"
      class="bg-white border-t border-b border-gray-500 text-gray-700 px-4 py-3 w-1/2 flex justify-center absolute"
    >
      <div
        v-if="!_.isEmpty(salesEachDay) && salesEachDayOpen"
        class="scrolling-auto overflow-auto h-screen mx-32"
      >
        <div class="my-2 flex justify-center">
          <span class="font-bold mt-2">Total Sales (showing max 100):</span>
          <span class="text-white bg-gray-800 mt-2 px-2 ml-1" v-text="salesEachDay.length"></span>
        </div>
        <table class="table-auto">
          <thead>
            <tr>
              <th class="px-4 py-2">Date Sold</th>
              <th class="px-4 py-2">Quantity</th>
              <th class="px-4 py-2">Price</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(sale, index) in salesEachDay">
              <td class="border px-4 py-2" v-text="sale.sold_at"></td>
              <td class="border px-4 py-2" v-text="sale.quantity">></td>
              <td class="border px-4 py-2" v-text="sale.price"></td>
            </tr>
          </tbody>
        </table>
      </div>
    </modal>

    <modal
      name="sales-each-month"
      class="bg-white border-t border-b border-gray-500 text-gray-700 px-4 py-3 w-1/2 flex justify-center absolute"
    >
      <div
        v-if="!_.isEmpty(salesEachMonth) && salesEachMonthOpen"
        class="scrolling-auto overflow-auto h-screen mx-32"
      >
        <table class="table-auto">
          <thead>
            <tr>
              <th class="px-4 py-2">Date Sold</th>
              <th class="px-4 py-2">Total Sold</th>
              <th class="px-4 py-2">Total Made</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(sale, index) in salesEachMonth">
              <td class="border px-4 py-2" v-text="sale.date"></td>
              <td class="border px-4 py-2" v-text="sale.total_sold">></td>
              <td class="border px-4 py-2" v-text="sale.total_made"></td>
            </tr>
          </tbody>
        </table>
      </div>
    </modal>
  </div>
</template>

<script>
export default {
  props: {
    productIdentifier: String,
    salesEachMonth: Array,
    salesEachDay: Array,
    metricSearchFlag: Boolean
  },
  data() {
    return {
      salesEachDayOpen: false,
      salesEachMonthOpen: false
    };
  },
  methods: {
    async getProductSalesEachDay() {
      this.openSalesPerDay();
      bus.$emit("productMetricSearhFlag", true);
      axios
        .get(`/products/ebay/sales?identifier=${this.productIdentifier}`)
        .then(
          res => {
            bus.$emit("salesEachDay", res.data);
            bus.$emit("productMetricSearhFlag", false);
            this.$modal.show("sales-each-day");
          },
          error => {
            this.getProductSalesEachDay();
          }
        );
    },
    async getProductSalesTotalEachMonth() {
      this.openSalesPerMonth();
      bus.$emit("productMetricSearhFlag", true);
      axios.get(`/api/products/${this.productIdentifier}/total-sales`).then(
        res => {
          bus.$emit("salesEachMonth", res.data.data);
          bus.$emit("productMetricSearhFlag", false);
          this.$modal.show("sales-each-month");
        },
        error => {
          this.getProductSalesTotalEachMonth();
        }
      );
    },
    openSalesPerDay() {
      this.salesEachMonthOpen = false;
      this.salesEachDayOpen = true;
    },
    openSalesPerMonth() {
      this.salesEachDayOpen = false;
      this.salesEachMonthOpen = true;
    }
  }
};
</script>

<style>
.abs-center {
  top: 50%;
  position: absolute;
  left: 50%;
  transform: translate3d(-50%, -50%, 0);
  background: #4241901f;
  border-radius: 50%;
}
</style>