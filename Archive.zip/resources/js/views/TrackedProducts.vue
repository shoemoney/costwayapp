<template>
  <div class="p-4">
    <div class="py-4 border-b border-gray-300" v-for="product in products">
      <a class="w-full hover:bg-gray-200" href="#">
        <div v-text="product.name"></div>
        <div class="text-sm text-gray-500">
          <span>
            Watched
            <span v-text="product.created_at"></span>
          </span>
          <div>
            Identifier
            <span class="text-gray-700" v-text="product.identifier"></span>
          </div>
          <div>
            Provider
            <span class="text-gray-700" v-text="product.provider"></span>
          </div>
          <div v-if="product.product[0].metrics[0].key === 'stock'">
            Stock
            <span class="text-gray-700" v-text="product.product[0].metrics[0].value"></span>
          </div>
        </div>
      </a>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    getProducts: Array
  },
  data() {
    return {};
  },
  methods: {
    productDetails(product) {
      bus.$emit("product", product);
    }
  },
  computed: {
    products() {
      return this.getProducts;
    }
  }
};
</script>
