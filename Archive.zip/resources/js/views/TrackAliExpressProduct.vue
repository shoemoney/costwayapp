<template>
  <div class="w-full p-2 flex justify-between text-gray-800">
    <div class="w-full p-2 mx-2 shadow px-6">
      <label class="font-bold my-2">Product ID</label>
      <input
        class="mt-1 py-1 px-2 block w-full leading-normal focus:outline-none"
        type="text"
        v-model="productId"
        v-on:keyup="productDetails"
      />
      <div v-if="!_.isEmpty(product)">
        <div class="my-2">
          <span class="font-bold">Available Stock:</span>
          <span
            v-text="product.stock"
            class="text-white bg-indigo-800 py-1 px-2 text-center px-4 py-1"
          ></span>
        </div>

        <label class="font-bold my-2">
          Price
          <span class="text-gray-600">Discount Added:</span>
          <span v-text="product.priceModule.discount"></span>%
        </label>
        <input
          class="mt-1 py-1 px-2 block w-full leading-normal focus:outline-none"
          type="text"
          v-model="product.priceModule.formatedActivityPrice"
        />

        <label class="font-bold my-2">Title</label>
        <textarea
          class="mt-1 py-1 px-2 block w-full leading-normal focus:outline-none"
          type="text"
          v-model="product.title"
          row="4"
          cols="30"
        />

        <label class="font-bold my-2">Description</label>
        <textarea
          class="mt-1 py-1 px-2 block w-full leading-normal focus:outline-none"
          type="text"
          v-model="product.description"
          rows="4"
          cols="30"
        />

        <span class="font-bold">Whole Description</span>
        <iframe :src="product.descriptionUrl" class="w-full h-64"></iframe>

        <label class="font-bold my-2">Keywords</label>
        <textarea
          class="mt-1 py-1 px-2 block w-full leading-normal focus:outline-none"
          type="text"
          v-model="product.keyWords"
          rows="4"
          cols="30"
        />
      </div>
    </div>
    <div class="w-1/2" v-if="!_.isEmpty(product)">
      <div class="shadow px-6 bg-white p-2">
        <span class="font-bold">Store details</span>
        <ul>
          <li>
            <span class="font-bold">Top Rated Seller:</span>
            <span v-text="product.store.topRatedSeller"></span>
          </li>
          <li>
            <span class="font-bold">Name:</span>
            <span v-text="product.store.name"></span>
          </li>
          <li>
            <span class="font-bold">URL:</span>
            <a :href="product.store.storeUrl" target="_blank" class="link">
              <span v-text="product.store.storeUrl"></span>
            </a>
          </li>
          <li>
            <span class="font-bold">Opened:</span>
            <span v-text="product.store.opened"></span>
          </li>
          <li>
            <span class="font-bold">Rating:</span>
            <span v-text="product.store.positiveRate"></span> out of:
            <span v-text="product.store.positiveNum"></span> ratings
          </li>
        </ul>
      </div>
      <!-- All Feedback Ratings
          <ul>
            <li
              v-for="(value, propertyName, index) in product.store.feedback.rating"
            >{{ propertyName }}: {{ value }} ({{ index }})</li>
      </ul>-->

      <div class="p-2 mt-2 shadow px-6 bg-gray-200">
        <button
          @click="downloadImages(product.images)"
          class="border-b-4 text-white border-indigo-600 bg-indigo-800 p-1 mt-2 active:border-indigo-700 hover:border-indigo-700 hover:bg-indigo-600 focus:outline-none focus:bg-indigo-600 px-4"
        >Download all images</button>
      </div>
      <button
        @click="trackProduct"
        class="border-b-4 text-white border-indigo-600 bg-indigo-700 p-1 mt-2 active:border-indigo-800 hover:border-indigo-800 hover:bg-indigo-600 focus:outline-none focus:bg-indigo-600 px-4 w-full"
      >Track Product</button>
    </div>
  </div>
</template>

<script>

import { saveAs } from 'file-saver';

export default {
  data() {
    return {
      product: {},
      productId: 0,
    };
  },
  methods: {
    productDetails() {
      if (this.productId.length >= 11) {
        axios.get(`/aliexpress/product/${this.productId}`).then(({ data }) => {
          this.product = data;
        });
      }
    },
    downloadImages(images) {
        images.forEach(image => {
          saveAs(image, image.replace('https://ae01.alicdn.com/kf/', ''));
      });
     
    },
    trackProduct() {
      axios
        .post("/aliexpress/product", {
          identifier: this.product.id,
          name: this.product.title,
          description: this.product.description,
          price: this.product.priceModule.maxActivityAmount,
          currency: this.product.currency,
          images: this.product.images,
          sellerinfo: this.product.store,
          url: this.product.itemUrl,
          keywords: this.product.keyWords || {},
          variation: this.product.variation || {},
          specs: this.product.specsModule || {},
          stock: this.product.stock
        })
        .then(response => {
          this.$toasted.show("Product tracked.", {
            theme: "bubble",
            position: "bottom-center",
            duration: 1500
          });
        });
    }
  }
};
</script>
