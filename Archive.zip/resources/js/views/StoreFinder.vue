<template>
  <div>
    <div class="mt-4 bg-white p-1">
      <div class="flex-grow"></div>
      <input
        class="mt-1 py-1 px-2 block w-full appearance-none leading-normal focus:outline-none"
        type="search"
        v-model="store"
        v-on:keyup="onSubmitSearchStore"
        placeholder="Search saved stores"
      />
    </div>
    <div>
      <ul class="bg-gray-300 p-4 shadow" v-if="!_.isEmpty(stores)">
        <li
          v-for="(store, index) in stores"
          v-text="store"
          @click="searchStore('ebay', store)"
          class="cursor-pointer bg-indigo-500 w-full p-1 mt-2 text-white text-center border-b-4 border-indigo-700 active:border-indigo-700 hover:bg-indigo-600 focus:outline-none focus:bg-indigo-600"
        ></li>
      </ul>
    </div>
    <div
      v-if="!_.isEmpty(selectedStore) && _.isEmpty(stores)"
      class="inline-flex text-center text-white bg-gray-300 p-4 shadow w-full"
    >
      <span
        v-text="selectedStore"
        class="border-b-4 border-indigo-700 w-full bg-indigo-500 p-1 mt-2"
      ></span>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      store: "",
      stores: [],
      page: 1,
      selectedStore: ""
    };
  },
  methods: {
    onSubmitSearchStore(e) {
      this.searchSavedStores(this.store, e);
      if (e.keyCode === 13) {
        this.searchStore("ebay", this.store);
      }
    },
    searchStore(vendor, store) {
      window.location.href = `/stores/${vendor}/${store}`;
    },
    searchSavedStores(store, e) {
      // If the search contains numbers or letters then search.
      if (!store.match(/^[0-9a-zA-Z]+$/) && e.keyCode !== 13) {
        return;
      }
      axios.get(`search/store/${store}`).then(({ data }) => {
        this.emptyStoresList();
        this.stores = data;
      });
    },
    emptyStoresList() {
      this.stores = [];
    }
  }
};
</script>
