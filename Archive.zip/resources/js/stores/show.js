
window.stores = new Vue({
    el: "#stores-show",
    data() {
        return {
            store: window.data.store,
            products: []
        };
    },
    methods: {
        getProducts(store) {
            axios.get(`/stores/${store.provider}/${store.identifier}/products`)
                .then(({ data }) => {
                    this.products = data;
                });
        },
        formattedDate(datetime) {
            return datetime.split(' ')[0];
        },
        imageUrl(product) {
            let image = _.find(product.metadata, (metadata) => {
                return metadata.key == 'images';
            });

            if (!image) {
                return "";
            }

            return image.value[0].url;
        }
    },
    mounted() {
        this.getProducts(this.store);
    }
});
