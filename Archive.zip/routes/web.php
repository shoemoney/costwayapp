<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::redirect('/', 'login');
Auth::routes();
Route::get('logout', 'Auth\LoginController@logout')->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('products', 'Products\ProductsController@index');

    Route::group(['prefix' => 'products/{provider}', 'namespace' => 'Products\Search'], function () {
        Route::get('/', 'KeywordsController')->middleware('terminate.store.products');
        Route::get('categories', 'CategoriesController')->middleware('terminate.store.products');
        Route::get('stores', 'StoresController')->middleware('terminate.store.products');
        Route::get('sales', 'SalesController')->middleware('terminate.store.sales');
    });

    Route::group(['prefix' => 'api', 'namespace' => 'Api'], function () {
        Route::resource('products', 'Products\ProductsController')->except(['create', 'edit']);
        Route::resource('products.sales', 'Products\SalesController')->except(['create', 'edit']);
        Route::get('products/{product}/total-sales', 'Products\GroupedSalesController@index');
    });

    Route::get('stores', 'StoresController@index');
    Route::get('stores/{provider}/{store}', 'StoresController@show');
    Route::get('stores/{provider}/{store}/products', 'StoreProductController@index');

    // Needs to be refactored to 'products'
    Route::get('product/{product}', 'ProductController@show');

    Route::resource('store', 'StoreController');
    Route::get('search/store/{store}', 'StoreController@search');
    Route::get('categories', 'CategoriesController@index');
    Route::get('search/categories/{category}', 'CategoriesController@search');

    Route::resource('import/product', 'ImportController');

    Route::resource('track/products', 'TrackedProductController');
    Route::get('search/tracked/products/{value}', 'TrackedProductController@search');

    //AliExpress routes
    Route::resource('aliexpress/product', 'AliExpress\ProductController');

    //Costway routes
    Route::resource('costway/product', 'Costway\ProductController');
});
