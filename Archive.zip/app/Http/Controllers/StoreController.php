<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\ModifyStoreRequest;
use App\Http\Resources\StoreResource;
use App\Models\Store;

class StoreController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return StoreResource::collection(
            Store::paginate()
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ModifyStoreRequest $request)
    {
        return StoreResource::make(
            Store::firstOrCreate(
                $request->validated()
            )->watchedBy(auth()->user())
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return StoreResource::make(
            Store::findOrFail($id)
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ModifyStoreRequest $request, $id)
    {
        $Store = Store::findOrFail($id);

        return StoreResource::make(
            tap($Store)->update(
                $request->validated()
            )
        );
    }

    /**
     * Search the stores list
     *
     * @param  string  $store
     * @return \Illuminate\Http\Response
     */
    public function search($store)
    {
        return response()->json(
            Store::where('identifier', 'LIKE', '%' . $store . '%')->get()->pluck('identifier')
        );
    }
}
