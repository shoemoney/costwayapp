<?php

namespace App\Http\Controllers\AliExpress;

use App\Integrations\AliExpress\Requests\GetProductRequest;
use App\Models\Product;
use App\Models\TrackedProduct;
use App\Repositories\MetadataRepository;
use App\Repositories\MetricsRepository;
use Illuminate\Http\Request;

class ProductController
{
    /**
     * Add product form
     *
     */
    public function index()
    {
        return view('product.aliexpress.index');
    }

    /**
     * Show the AliExpress product Details
     *
     * @param  int  $productId
     * @return \Illuminate\Http\Response
     */
    public function show($productId)
    {
        return response()->json(app(GetProductRequest::class)->product($productId));
    }

    /**
     * Store the product
     *
     * @param  int  $productId
     * @return \Illuminate\Http\Reques
     */
    public function store(Request $request)
    {
        $request->validate([
            'identifier' => 'required',
            'name' => 'required',
            'description' => 'required',
            'price' => 'required',
            'currency' => 'required',
            'images' => 'required',
            'sellerinfo' => 'required',
            'url' => 'required',
            'stock' => 'required',

        ]);

        $product = Product::updateOrCreate([
            'identifier' => $request->get('identifier'),
        ], [
            'provider' => "aliexpress",
            'identifier' => $request->get('identifier'),
            'name' => $request->get('name'),
            'description' => $request->get('description'),
            'price' => $request->get('price'),
            'currency' => $request->get('currency'),
            'user_id' => auth()->user()->id,
        ]);

        app(MetadataRepository::class)->storeMany($product, collect(
            [
                'images' => $request->get('images'),
                'sellerinfo' => $request->get('sellerinfo'),
                'url' => $request->get('url'),
                'keywords' => $request->get('keywords'),
                'variation' => $request->get('variation'),
                'specs' => $request->get('specs'),
            ]
        ));

        app(MetricsRepository::class)->storeMany($product, collect(
            [
                'stock' => $request->get('stock'),
            ]
        ));

        app(TrackedProduct::class)->createLink([
            'identifier' => $request->get('identifier'),
            'name' => $request->get('name'),
            'provider' => 'aliexpress',
        ]);
    }
}
