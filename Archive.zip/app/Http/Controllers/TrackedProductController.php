<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\ModifyTrackedProductRequest;
use App\Http\Resources\TrackedProductResource;
use App\Models\TrackedProduct;

class TrackedProductController extends Controller
{

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ModifyTrackedProductRequest $request)
    {
        return TrackedProductResource::make(
            TrackedProduct::create(
                $request->validated()
            )
        );
    }

    /**
     * Return tracked product view
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = TrackedProduct::with(
            'product',
            'product.metadata',
            'product.metrics',
            'product.store',
        )
            ->where('user_id', auth()->user()->id)
            ->get();

        return view('trackedproducts.index', compact('products'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return TrackedProduct::with(
            'product',
            'product.metadata',
            'product.store',
        )->findOrFail($id);
    }

    /**
     * Search the tracked products list
     *
     * @param  string  $store
     * @return \Illuminate\Http\Response
     */
    public function search($value)
    {
        return response()->json(
            TrackedProduct::with(
                'product',
                'product.metadata',
                'product.store',
            )
                ->where('identifier', 'LIKE', '%' . $value . '%')
                ->orWhere('name', 'LIKE', '%' . $value . '%')
                ->orWhere('provider', $value)
                ->get()
        );
    }
}
