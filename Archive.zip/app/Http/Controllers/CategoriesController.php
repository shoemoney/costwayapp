<?php

namespace App\Http\Controllers;

use App\Models\Product\Category;

class CategoriesController
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Category::paginate();
    }

    /**
     * Search the categories list
     *
     * @param  string  $category
     * @return \Illuminate\Http\Response
     */
    public function search($category)
    {
        return response()->json(
            Category::where('name', 'LIKE', '%' . $category . '%')->paginate(6)
        );
    }
}
