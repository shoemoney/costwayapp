<?php

namespace App\Http\Controllers;

use App\Models\Store;

class StoresController
{
    /**
     * Display a listing of stores.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $watchedStores = auth()->user()->watching()
            ->where('watchable_type', Store::class)
            ->with('watchable')
            ->get();

        return view('stores.index', [
            'watchers' => $watchedStores
        ]);
    }

    /**
     * Display a store's page.
     *
     * @param  string  $provider
     * @param  string  $storeIdentifier
     * @return \Illuminate\Http\Response
     */
    public function show($provider, $storeIdentifier)
    {
        $store = Store::where('provider', $provider)
            ->where('identifier', $storeIdentifier)
            ->orWhere('name', $storeIdentifier)
            ->firstOrFail();

        return view('stores.show', [
            'store' => $store
        ]);
    }
}
