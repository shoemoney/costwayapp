<?php

namespace App\Http\Controllers\Products\Search;

use Illuminate\Http\Request;

class SalesController
{
    /**
     * Get the sales for a product at a provider.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $provider
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, $provider)
    {
        return integration($provider)->products()
            ->sales($request->get('identifier'))
            ->toModels();
    }
}
