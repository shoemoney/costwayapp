<?php

namespace App\Http\Controllers\Products\Search;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class KeywordsController extends Controller
{
    /**
     * Search for products on a given provider.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $provider
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, $provider)
    {
        return integration('ebay')->detailedSearch()
            ->keyword($request->query('keyword', ''), $request->query('page', 1))
            ->getBody()
            ->toModels();
    }
}
