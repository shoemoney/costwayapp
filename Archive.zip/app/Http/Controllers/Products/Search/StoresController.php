<?php

namespace App\Http\Controllers\Products\Search;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class StoresController extends Controller
{
    /**
     * Search for products on a given provider.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $provider
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, $provider)
    {
        return integration('ebay')->detailedSearch()
            ->store($request->query('identifier'), $request->query('page', 1))
            ->getBody()
            ->toModels();
    }
}
