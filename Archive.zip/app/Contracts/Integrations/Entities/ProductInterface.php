<?php

namespace App\Contracts\Integrations\Entities;

interface ProductInterface
{
}
