<?php

namespace App\Models;

use App\Http\Resources\TrackedProductResource;
use App\Models\Product;
use App\Models\Store;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class TrackedProduct extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'identifier', 'provider', 'name', 'store_id', 'store', 'user_id',
    ];

    /**
     * Get all imported products
     *
     * @return \Illuminate\Database\Eloquent\Relations\hasOne
     */
    public function product()
    {
        return $this->hasMany(Product::class, 'identifier', 'identifier');
    }

    /**
     * Get the user who tracked the product.
     *
     * @return \Illuminate\Database\Eloquent\Relations\hasOne
     */
    public function user()
    {
        return $this->hasOne(User::class, 'id', 'user_id');
    }

    /**
     * Create a link to the imported product
     *
     * @param  \Illuminate\Http\Array  $data
     * @return \Illuminate\Http\Response
     */
    public function createLink(array $data)
    {
        // If the product link already exists don't create a new one
        // if ($this->where('identifier', $data['identifier'])->count() > 0) {
        //     return;
        // }

        // We allow individuals to link a product, even if they don't have the product in their sellers list.
        //If there isn't a store, just make it null.
        if (empty($data['store'])) {
            $data['store'] = null;
        }

        return TrackedProductResource::make(
            $this->updateOrCreate([
                'identifier' => $data['identifier'],
            ], [
                'identifier' => $data['identifier'],
                'provider' => $data['provider'],
                'name' => $data['name'],
                'store_id' => optional(Store::where('identifier', $data['store']))->first()->id ?? 0,
                'store' => $data['store'],
                'user_id' => auth()->user()->id,
            ])
        );
    }

    /**
     * Search the imported products list
     *
     * @param  string  $store
     * @return \Illuminate\Http\Response
     */
    public function search($value)
    {
        return $this->with('product', 'product.metadata', 'product.metrics', 'product.store')
            ->where('user_id', auth()->user()->id)
            ->orWhere('identifier', 'LIKE', '%' . $value . '%')
            ->orWhere('name', 'LIKE', '%' . $value . '%')
            ->orWhere('provider', $value)
            ->get();
    }
}
