<?php

namespace App\Models;

use App\Models\Product\StoreProduct;
use App\Models\Store;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'provider', 'identifier', 'name', 'description',
        'price', 'currency', 'user_id',
    ];

    /**
     * A product has many sales.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function sales()
    {
        return $this->hasMany("App\Models\Product\Sale");
    }

    /**
     * A product has many categories through the product_categories table.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasManyThrough
     */
    public function categories()
    {
        return $this->hasManyThrough("App\Models\Product\Category", "App\Models\Product\ProductCategory");
    }

    /**
     * A product has many metadata tags.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function metadata()
    {
        return $this->hasMany("App\Models\Product\Meta");
    }

    /**
     * A product has many metrics.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function metrics()
    {
        return $this->hasMany("App\Models\Product\Metric");
    }

    /**
     * Get the store that this product belongs to.
     *
     * @return \Illuminate\Database\Eloquent\Relations\hasOneThrough
     */
    public function store()
    {
        return $this->hasOneThrough('App\Models\Store', 'App\Models\Product\StoreProduct', 'product_id', 'id', 'id', 'store_id');
    }

    /**
     * Get the user who tracked the product.
     *
     * @return \Illuminate\Database\Eloquent\Relations\hasOne
     */
    public function user()
    {
        return $this->hasOne('App\Models\User', 'id', 'user_id');
    }

    /**
     * Scope the query to products sold by a given store.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  \App\Models\Store  $store
     * @return \Illuminate\Database\Query\Builder
     */
    public function scopeSoldBy(Builder $query, Store $store)
    {
        return $query->whereIn(
            'id',
            StoreProduct::select('product_id')->where('store_id', $store->id)
        );
    }
}
