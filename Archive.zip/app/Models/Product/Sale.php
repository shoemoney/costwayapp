<?php

namespace App\Models\Product;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'provider', 'product_id', 'quantity', 'price',
        'currency', 'sold_at'
    ];

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = "product_sales";

    /**
     * Get the "sold_at" attribute.
     *
     * @return Carbon\Carbon
     */
    public function getSoldAtAttribute()
    {
        return $this->asDate($this->attributes['sold_at']);
    }

    /**
     * Set the "sold_at" attribute.
     *
     * @param  string  $soldAt
     * @return void
     */
    public function setSoldAtAttribute($soldAt)
    {
        $this->attributes['sold_at'] = Carbon::parse($soldAt);
    }

    /**
     * Get the "price" attribute.
     *
     * @return float
     */
    public function getPriceAttribute()
    {
        return (float) sprintf("%.2f", ($this->attributes['price'] / 100));
    }

    /**
     * Set the "price" attributes.
     *
     * @param  float|int|string  $price
     * @return void
     */
    public function setPriceAttribute($price)
    {
        $decimalPlaces = min(
            strlen(substr(strrchr($price, "."), 1)),
            2
        );

        $this->attributes['price'] = (int)($price * pow(10, $decimalPlaces));
    }

    /**
     * Get the "total_cost" attribute.
     *
     * @return int
     */
    public function getTotalCostAttribute()
    {
        return $this->price * $this->quantity;
    }
}
