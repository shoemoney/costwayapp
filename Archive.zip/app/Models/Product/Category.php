<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'provider', 'identifier', 'name', 'parent_id'
    ];

    /**
     * A category can belong to a parent category.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo|null
     */
    public function parent()
    {
        return $this->belongsTo(static::class, 'parent_id', 'identifier');
    }
}
