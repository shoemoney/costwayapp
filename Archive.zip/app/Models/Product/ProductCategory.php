<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Relations\Pivot;

class ProductCategory extends Pivot
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'category_id', 'product_id'
    ];

    /**
     * Indicates if the IDs are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = true;

    /**
     * The product this pivots to.
     *
     * @return \Illuminate\Database\ELoquent\Relations\BelongsTo
     */
    public function product()
    {
        return $this->belongsTo("App\Models\Product");
    }

    /**
     * The category this pivots to.
     *
     * @return \Illuminate\Database\ELoquent\Relations\BelongsTo
     */
    public function category()
    {
        return $this->belongsTo("App\Models\Product\Category");
    }
}
