<?php

namespace App\Console\Commands;

use App\Events\PriceChanged;
use App\Events\StockLow;
use App\Integrations\AliExpress\Requests\GetProductRequest;
use App\Models\TrackedProduct;
use App\Repositories\MetricsRepository;
use Illuminate\Console\Command;

class AliExpressProductStockPrice extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'product:aliexpress';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update the stock or price on a product';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $products = app(TrackedProduct::class)
            ->with('product', 'product.metrics', 'user')
            ->where('provider', 'aliexpress')
            ->get();

        foreach ($products as $product) {
            $aliExpressProduct = app(GetProductRequest::class)->product(
                $product->identifier
            );

            $AliExpressActivePrice = $aliExpressProduct['priceModule']['maxActivityAmount'];
            $AliExpressStock = $aliExpressProduct['stock'];

            $product = $product->product->first();

            $activePrice = $product->price;
            $stock = (int) $product->metrics->first()->value;

            if ($AliExpressActivePrice != $activePrice) {
                event(new PriceChanged($product, $AliExpressActivePrice, "https://www.aliexpress.com/item/"));
                $product->update(['price' => $AliExpressActivePrice]);
            }

            if ($AliExpressStock < $stock) {
                if ($AliExpressStock < 10) {
                    event(new StockLow($product, $AliExpressStock));
                }

                app(MetricsRepository::class)->storeMany(
                    $product,
                    collect([
                        'stock' => $AliExpressStock,
                    ])
                );
            }
        }
    }
}
