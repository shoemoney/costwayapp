<?php

namespace App\Repositories;

use App\Models\Store;
use App\Models\Product\StoreProduct;

class StoresRepository
{
    /**
     * Persist a store in storage.
     *
     * @param  array  $store
     * @return \App\Models\Store
     */
    public function store(array $store)
    {
        return Store::firstOrCreate([
            'identifier' => $store['identifier'],
            'provider' => $store['provider']
        ]);
    }

    /**
     * Create a link between a store and a product.
     *
     * @param  int  $storeId
     * @param  int  $productId
     * @return \App\Models\Product\StoreProduct
     */
    public function linkProductToStore($storeId, $productId)
    {
        return StoreProduct::firstOrCreate([
            'store_id' => $storeId,
            'product_id' => $productId
        ]);
    }
}
