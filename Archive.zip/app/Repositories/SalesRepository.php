<?php

namespace App\Repositories;

use App\Models\Product;
use App\Models\Product\Sale;
use Illuminate\Support\Collection;

class SalesRepository
{
    /**
     * Find the sales for a given product.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function forProduct(Product $product)
    {
        return $product->sales();
    }

    /**
     * Find the specific sale for a product.
     *
     * @param  \App\Models\Product  $product
     * @param  mixed  $id
     * @return \App\Models\Products\Sale|null
     */
    public function find(Product $product, $id)
    {
        return $this->forProduct($product)
            ->where('id', $id)
            ->first();
    }

    /**
     * Store many sales for a given product.
     *
     * @param  \App\Models\Product  $product
     * @param  \Illuminate\Support\Collection  $sales
     * @return \Illuminate\Support\Collection
     */
    public function storeMany(Product $product, Collection $sales)
    {
        return $sales->map(function ($sale) use ($product) {
            return Sale::create([
                'quantity' => $sale['quantity'],
                'price' => $sale['price'],
                'sold_at' => $sale['sold_at'],
                'product_id' => $product->id,
                'provider' => $product->provider,
            ]);
        });
    }
}
