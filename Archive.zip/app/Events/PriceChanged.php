<?php

namespace App\Events;

use App\Models\Product;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class PriceChanged
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /** @var \App\Models\Product */
    public $product;

    /** @var int */
    public $price;

    /** @var string */
    public $url;

    /**
     * Create a new event instance.
     *
     * @param  \App\Models\Product $product
     * @param  int $price
     * @return void
     */
    public function __construct(Product $product, int $price, string $url)
    {
        $this->product = $product;
        $this->price = $price;
        $this->url = $url;
    }
}
