<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTrackedProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tracked_products', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('identifier', 255);
            $table->string('provider', 100);
            $table->string('name', 250)->nullable();
            $table->unsignedBigInteger('store_id')->nullable();
            $table->string('store', 250)->nullable();
            $table->unsignedBigInteger('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->index('user_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tracked_products');
    }
}
